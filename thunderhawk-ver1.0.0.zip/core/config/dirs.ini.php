;<?php die(); __halt_compiler(); ?>

[dirs]

;PRIVATE

core.api		= CORE_PATH "API/"
core.modules	= CORE_PATH "modules/"
core.cache.base	= CORE_PATH "cache/"
core.cache.volt	= CORE_PATH "cache/volt/"
core.logs		= CORE_PATH "logs/"
core.plugins 	= CORE_PATH "plugins/"
core.themes		= CORE_PATH "themes/"
core.config		= CORE_PATH "config/"

;PUBLIC

public.assets		= APP_PATH "public/assets/"