<?php
// MODULES INSTALLED
$modulesInstalled = array(
		'modules' => 
		[	'installed' => 
				[
						/* module name */	/* module path */
						'frontend' 		=>	CORE_PATH .'modules/frontend/',
						'backend'		=> 	CORE_PATH .'modules/backend/' 
						
				],
			/* the default module name */
			'default' => 'frontend'
		]
);