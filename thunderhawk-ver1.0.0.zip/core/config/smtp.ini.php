;<?php die(); __halt_compiler(); ?>

[smtp]

host		= "in-v3.mailjet.com"
port		= 465
encryption	= "ssl"
username	= "85af1b04008e32814309136f3e7e4fe8"
password	= "2bc427be64055d0f9e7ba935abcc8e34"

from		= "ivan.maruca@gmail.com"