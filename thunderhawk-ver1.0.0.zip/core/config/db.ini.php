;<?php die(); __halt_compiler(); ?>

[db]

host			= "localhost"
username		= "root"
;password		= "9G16EJpc"
;dbname			= "prv001_area51"
password		= ""
dbname			= "area_riservata"

adapter			= Mysql
table.prefix 	= ""



