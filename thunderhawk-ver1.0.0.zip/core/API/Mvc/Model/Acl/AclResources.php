<?php

namespace Thunderhawk\API\Mvc\Model\Acl;
use Thunderhawk\API\Mvc\Model;
class AclResources extends Model{
	public $name;
	public $description;
}