<?php

namespace Thunderhawk\API\Mvc\Model\Acl;
use Thunderhawk\API\Mvc\Model;
class AclResourcesAccess extends Model{
	public $resources_name;
	public $access_name;
}