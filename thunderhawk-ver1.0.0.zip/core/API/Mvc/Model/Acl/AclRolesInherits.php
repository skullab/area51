<?php

namespace Thunderhawk\API\Mvc\Model\Acl;
use Thunderhawk\API\Mvc\Model;
class AclRolesInherits extends Model {
	public $roles_name;
	public $roles_inherits;
}