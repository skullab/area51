<?php

namespace Thunderhawk\API\Mvc\Model\Acl;

use Thunderhawk\API\Mvc\Model;

class AclRoles extends Model {
	public $name ;
	public $description ;
}