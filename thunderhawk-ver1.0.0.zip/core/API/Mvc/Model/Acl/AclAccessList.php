<?php

namespace Thunderhawk\API\Mvc\Model\Acl;
use Thunderhawk\API\Mvc\Model;
class AclAccessList extends Model{
	public $roles_name;
	public $resources_name;
	public $access_name;
	public $allowed;
}

