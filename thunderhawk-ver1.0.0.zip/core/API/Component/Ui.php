<?php

namespace Thunderhawk\API\Component;
use Phalcon\Mvc\User\Component;
class Ui extends Component {
}