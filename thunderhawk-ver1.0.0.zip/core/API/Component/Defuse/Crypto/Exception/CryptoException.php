<?php

namespace Thunderhawk\API\Component\Defuse\Crypto\Exception;
class CryptoException extends \Exception{
}