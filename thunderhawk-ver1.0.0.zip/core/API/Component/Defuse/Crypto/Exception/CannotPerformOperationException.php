<?php
namespace Thunderhawk\API\Component\Defuse\Crypto\Exception;
class CannotPerformOperationException extends CryptoException{
}