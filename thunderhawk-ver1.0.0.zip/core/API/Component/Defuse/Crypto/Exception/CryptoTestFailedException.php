<?php
namespace Thunderhawk\API\Component\Defuse\Crypto\Exception;
class CryptoTestFailedException extends CryptoException{
}