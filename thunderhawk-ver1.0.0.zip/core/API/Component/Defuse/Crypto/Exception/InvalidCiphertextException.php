<?php
namespace Thunderhawk\API\Component\Defuse\Crypto\Exception;
class InvalidCiphertextException extends CryptoException{
}