<?php

namespace Thunderhawk\API\Component\Settings;

class AppSettings extends BaseModel{
	public $name ;
}