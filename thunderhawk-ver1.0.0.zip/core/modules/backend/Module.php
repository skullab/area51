<?php

namespace Vendor\Backend;
use Thunderhawk\API\Adapter\Module as ModuleAdapter;
class Module extends ModuleAdapter{
}