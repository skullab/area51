<?php

namespace Thunderhawk\Modules\Frontend;
use Thunderhawk\API\Adapter\Module as ModuleAdapter;
class Module extends ModuleAdapter{
} 