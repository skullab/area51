/*!
 * remark v1.0.1 (http://getbootstrapadmin.com/remark)
 * Copyright 2015 amazingsurge
 * Licensed under the Themeforest Standard Licenses
 */
$.components.register("TouchSpin", {
  mode: "default",
  defaults: {
    verticalupclass: "wb-plus",
    verticaldownclass: "wb-minus",
    buttondown_class: "btn btn-outline btn-default",
    buttonup_class: "btn btn-outline btn-default"
  }
});
